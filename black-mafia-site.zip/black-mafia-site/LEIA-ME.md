# BLACK MÁFIA — guia de publicação

## O que tem na pasta
- `index.html` — a loja (página principal)
- `css/style.css` — visual (cores, tamanhos, layout de celular)
- `js/main.js` — catálogo, carrinho, checkout e Pix. **É aqui que você edita preços, estoque, chave Pix e contatos** (bloco `STORE` no topo)
- `images/` — fotos dos produtos
- `favicon.svg` — ícone da aba do navegador
- `404.html` — página de endereço não encontrado
- `robots.txt` e `sitemap.xml` — arquivos para o Google (veja a parte 4)

## 1. Como baixar os arquivos
1. No chat, toque no arquivo `black-mafia-site.zip` e use a opção de baixar/salvar.
2. **Celular:** abra o app Arquivos (ou Downloads), toque no .zip e escolha extrair/descompactar.
3. **Computador:** clique com o botão direito no .zip e escolha "Extrair tudo".
4. Você deve ver a pasta `black-mafia-site` com o `index.html` dentro dela. Se o `index.html` estiver dentro de outra pasta, publique essa pasta interna.

## 2. Como publicar (grátis) e ter um link
**Opção A: Netlify Drop (recomendada)**
1. Abra https://app.netlify.com/drop
2. Arraste a pasta `black-mafia-site` (ou escolha a pasta/o .zip). A documentação do Netlify recomenda descompactar antes.
3. Em segundos você recebe um link terminando em `.netlify.app`.
4. **Crie uma conta grátis e reivindique o site.** Sites que ninguém reivindica são apagados depois de cerca de uma hora.
5. Para ter um endereço fácil (ex.: `blackmafia.netlify.app`), renomeie o projeto nas configurações do site, no campo de nome do projeto. Se o nome já existir, tente outro.

**Opção B: Vercel Drop** (aceita o .zip direto, bom para celular)
1. Abra https://vercel.com/drop
2. Escolha o arquivo `black-mafia-site.zip`, defina um nome de projeto e toque em Deploy.
3. Use o plano gratuito (Hobby).

**Domínio próprio (opcional, pago):** algo como `blackmafia.com.br` se registra no Registro.br (cerca de R$ 40 por ano) e se liga ao site nas configurações de domínio do Netlify ou Vercel. Não é obrigatório.

## 3. Como atualizar o site depois
- Mude preço, estoque, chave Pix ou contatos em `js/main.js`, no bloco `STORE`.
- Exemplos: `price:10` (preço), `stock:true` (disponível) ou `stock:false` (esgotado).
- No Netlify, abra o projeto, vá em Deploys e arraste a pasta atualizada para publicar a nova versão.

## 4. Como cadastrar no Google (grátis)
1. **Troque o endereço nos arquivos:** em `sitemap.xml` e `robots.txt`, troque `SEU-SITE.netlify.app` pelo seu endereço real. Publique de novo.
2. Entre em https://search.google.com/search-console com sua conta Google.
3. Clique em **Adicionar propriedade** e escolha **Prefixo do URL**. Digite o endereço completo com `https://` e a barra no final (ex.: `https://blackmafia.netlify.app/`).
4. Na verificação, escolha **Tag HTML**, copie a meta tag e cole no `index.html`, no lugar indicado pelo comentário dentro do `<head>`. Publique de novo e clique em **Verificar**.
5. No menu **Sitemaps**, digite `sitemap.xml` e envie.
6. No campo de busca do topo (Inspeção de URL), cole o endereço da página inicial e clique em **Solicitar indexação**.
7. Aguarde. Pode levar de alguns dias a algumas semanas, e o Google não garante a posição. Divulgar o link no Discord e nas redes ajuda.

## Avisos
- Antes de divulgar, faça um Pix de teste de poucos centavos para conferir se a chave está certa.
- O Roblox proíbe vender itens do jogo por dinheiro real fora da plataforma. Isso pode gerar punição à sua conta ou ao jogo.
- As fotos dos produtos devem ser suas ou ter permissão de uso.
