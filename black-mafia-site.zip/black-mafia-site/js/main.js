// EDITE AQUI.
// price: número (ex.: 25.9) ou null para "Valor a definir". oldPrice: opcional, mostra preço riscado e desconto.
// stock: true = disponível, false = "Estoque esgotado". photo: imagem embutida (data:) ou "" para espaço reservado.
const STORE={
 pixKey:"56cd076e-5110-4ff5-99af-7c00dcbf4e8d", pixName:"",
 contacts:[{label:"Discord",value:"discord.gg/rdpH4shkX",url:"https://discord.gg/rdpH4shkX"},{label:"WhatsApp",value:"",url:""},{label:"Instagram",value:"",url:""}],
 items:[
  {name:"Arma Natalina",price:10,oldPrice:null,stock:false,photo:"images/arma-natalina.jpg"},
  {name:"Páscoa",price:9,oldPrice:null,stock:false,photo:"images/pascoa.jpg"},
  {name:"Fuzil Ninja",price:8,oldPrice:null,stock:false,photo:"images/fuzil-ninja.jpg"}
 ]};
const $=id=>document.getElementById(id);
const cart=[];
const money=v=>v==null?null:v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
function toast(t){const e=$("toast");e.textContent=t;e.classList.add("on");setTimeout(()=>e.classList.remove("on"),1800)}
const ICON='<svg viewBox="0 0 24 24"><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.7 12.4a2 2 0 0 0 2 1.6h7.6a2 2 0 0 0 2-1.5L21 8H6"/></svg>';
function renderGrid(){
 const term=$("q").value.trim().toLowerCase();
 const list=STORE.items.map((it,i)=>({it,i})).filter(o=>o.it.name.toLowerCase().includes(term));
 $("grid").innerHTML=list.length?list.map(({it,i})=>{const p=money(it.price);
  const off=it.oldPrice&&it.price!=null?Math.round((1-it.price/it.oldPrice)*100):0;
  return `<article class="card"><div class="photo${it.photo?" has":""}">${it.photo?`<img src="${it.photo}" alt="${it.name}">`:"Foto do produto"}${it.stock?"":'<div class="sold">ESTOQUE ESGOTADO</div>'}</div>
  <div class="body"><h3>${it.name}</h3>${off?`<div><span class="old">${money(it.oldPrice)}</span><span class="off">-${off}%</span></div>`:""}
  <div class="price ${p?"":"tbd"}">${p||"Valor a definir"}</div><div class="pix">À vista no Pix</div>
  <button class="btn" type="button" data-i="${i}" ${it.stock?"":"disabled"}>${ICON}${it.stock?"Comprar agora":"Indisponível"}</button></div></article>`}).join(""):'<p class="empty">Nenhum produto encontrado.</p>';
}
const lineTotal=c=>{const p=STORE.items[c.i].price;return p==null?null:p*c.q};
const total=()=>cart.length&&cart.every(c=>STORE.items[c.i].price!=null)?cart.reduce((t,c)=>t+STORE.items[c.i].price*c.q,0):null;
const thumb=it=>`<div class="th">${it.photo?`<img src="${it.photo}" alt="">`:""}</div>`;
function renderCart(){
 $("cnt").textContent=cart.reduce((t,c)=>t+c.q,0)||"";
 const t=total();
 $("empty").hidden=cart.length>0;$("flow").style.display=cart.length?"grid":"none";
 $("pay").textContent=t!=null?"Pagar "+money(t):"Finalizar pedido";
 $("lines").innerHTML=cart.map((c,n)=>{const it=STORE.items[c.i];
  return `<div class="li">${thumb(it)}<div class="nm"><b>${it.name}</b><small>${money(it.price)||"Valor a definir"}</small></div>
  <div class="qt"><button type="button" data-d="-1" data-n="${n}" aria-label="Diminuir">−</button><span>${c.q}</span><button type="button" data-d="1" data-n="${n}" aria-label="Aumentar">+</button><button type="button" class="rm" data-rm="${n}" aria-label="Remover">×</button><div class="lt">${money(lineTotal(c))||""}</div></div></div>`}).join("");
 const more=STORE.items.map((it,i)=>({it,i})).filter(o=>o.it.stock&&!cart.some(c=>c.i===o.i));
 $("mh").hidden=!more.length;
 $("more").innerHTML=more.map(({it,i})=>`<div class="up">${thumb(it)}<div class="nm"><b>${it.name}</b><small>${money(it.price)||"Valor a definir"}</small></div><button class="btn" type="button" data-add="${i}">+ Adicionar</button></div>`).join("");
}
function openCart(o){document.body.classList.toggle("open",o);if(o){$("done").hidden=true;renderCart();$("co").scrollTop=0}}
function add(i){const c=cart.find(x=>x.i===i);if(!c)cart.push({i,q:1});renderCart()}
$("grid").addEventListener("click",e=>{const b=e.target.closest("button[data-i]");if(b){add(+b.dataset.i);openCart(true)}});
$("co").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
 if(b.dataset.add!=null)add(+b.dataset.add);
 else if(b.dataset.rm!=null){cart.splice(+b.dataset.rm,1);renderCart()}
 else if(b.dataset.d){const c=cart[+b.dataset.n];c.q=Math.max(1,Math.min(9,c.q+ +b.dataset.d));renderCart()}});
$("bc").onclick=()=>openCart(true);
$("back").onclick=$("back2").onclick=$("tocontact").onclick=()=>openCart(false);
$("bs").onclick=()=>{$("search").classList.toggle("on");if($("search").classList.contains("on"))$("q").focus()};
$("q").oninput=renderGrid;
$("pixkey").textContent=STORE.pixKey||"Chave Pix a cadastrar";
$("pixname").textContent=STORE.pixName?("Favorecido: "+STORE.pixName):"";
$("contacts").innerHTML=STORE.contacts.map(c=>`<a ${c.url?`href="${c.url}" target="_blank" rel="noopener"`:'href="#contato"'}>${c.label}<small>${c.value||"A cadastrar"}</small></a>`).join("");
async function copy(t,ok){try{await navigator.clipboard.writeText(t);toast(ok)}catch(e){toast("Não foi possível copiar")}}
$("pay").onclick=()=>{
 if(!$("nome").value.trim()||!$("user").value.trim())return toast("Preencha seu nome e usuário no Roblox");
 if(!$("ok").checked)return toast("Aceite as condições para continuar");
 const t=total();$("dtotal").textContent=t!=null?money(t):"a combinar";
 $("flow").style.display="none";$("done").hidden=false;$("co").scrollTop=0};
$("cpix").onclick=()=>STORE.pixKey?copy(STORE.pixKey,"Chave Pix copiada"):toast("Chave Pix ainda não cadastrada");
$("cmsg").onclick=()=>{
 const itens=cart.map(c=>"- "+c.q+"x "+STORE.items[c.i].name+" ("+(money(STORE.items[c.i].price)||"valor a combinar")+")").join("\n");
 copy(`Olá! Quero comprar na BLACK MÁFIA:\n${itens}\nTotal: ${$("dtotal").textContent}\nNome: ${$("nome").value}\nUsuário no Roblox: ${$("user").value}\nContato: ${$("contato").value||"-"}\nVou enviar o comprovante do Pix.`,"Mensagem copiada")};
renderGrid();renderCart();
